package com.services.cart.controller;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/cart")
public class CartController {

	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@RequestMapping("/getAllValues")
	public String getAllValues(){
		return "return all Values";
	}
	
	
	@RequestMapping("/getAll")
	public String getAll(){
		//byte[] decodedBytes = Base64.getDecoder().decode(password);
		String check=restTemplate.getForObject("http://greetings/greetings/current", String.class);
	//	String passwords=new String(decodedBytes);
		return check+" all "+" "+check;
	}
	
}
